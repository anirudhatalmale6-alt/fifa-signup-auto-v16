// Get current lock status
chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
  updateUI(response.isLocked);
});

// Toggle lock button
document.getElementById('toggleBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'toggleLock' }, (response) => {
    updateUI(response.isLocked);
  });
});

// Apply now button
document.getElementById('applyBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'applyNow' }, (response) => {
    if (response.success) {
      updateUI(true);
    }
  });
});

function updateUI(isLocked) {
  const statusEl = document.getElementById('status');
  const toggleBtn = document.getElementById('toggleBtn');

  if (isLocked) {
    statusEl.textContent = 'LOCKED';
    statusEl.className = 'status locked';
    toggleBtn.textContent = 'UNLOCK WINDOW';
    toggleBtn.classList.add('active');
  } else {
    statusEl.textContent = 'UNLOCKED';
    statusEl.className = 'status unlocked';
    toggleBtn.textContent = 'LOCK WINDOW';
    toggleBtn.classList.remove('active');
  }
}
