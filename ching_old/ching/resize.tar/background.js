/**
 * Window Size Lock - Background Service Worker
 * Locks window to 800x600 and 75% zoom, prevents any resize
 */

const LOCKED_WIDTH = 800;
const LOCKED_HEIGHT = 600;
const LOCKED_ZOOM = 0.75;  // 75%

let isLocked = false;
let lockedWindowId = null;

// Apply locked size and zoom to a window
async function applyLockedSize(windowId) {
  try {
    await chrome.windows.update(windowId, {
      width: LOCKED_WIDTH,
      height: LOCKED_HEIGHT,
      state: 'normal'
    });
    console.log('[WindowLock] Applied locked size:', LOCKED_WIDTH, 'x', LOCKED_HEIGHT);

    // Apply zoom to all tabs in this window
    const tabs = await chrome.tabs.query({ windowId: windowId });
    for (const tab of tabs) {
      try {
        await chrome.tabs.setZoom(tab.id, LOCKED_ZOOM);
      } catch (e) {
        // Some tabs can't be zoomed (chrome:// pages)
      }
    }
    console.log('[WindowLock] Applied zoom:', LOCKED_ZOOM * 100 + '%');
  } catch (err) {
    console.error('[WindowLock] Error applying size:', err);
  }
}

// Monitor window bounds changes and revert if locked
chrome.windows.onBoundsChanged.addListener(async (window) => {
  if (!isLocked || window.id !== lockedWindowId) return;

  // Check if size changed from locked size
  if (window.width !== LOCKED_WIDTH || window.height !== LOCKED_HEIGHT) {
    console.log('[WindowLock] Detected resize attempt, reverting...');
    await applyLockedSize(window.id);
  }
});

// Apply zoom to new tabs
chrome.tabs.onCreated.addListener(async (tab) => {
  if (!isLocked) return;

  if (tab.windowId === lockedWindowId) {
    // Wait for tab to load
    setTimeout(async () => {
      try {
        await chrome.tabs.setZoom(tab.id, LOCKED_ZOOM);
        console.log('[WindowLock] Applied zoom to new tab');
      } catch (e) {
        // Some tabs can't be zoomed
      }
    }, 500);
  }
});

// Apply zoom when tab updates (navigates)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!isLocked || changeInfo.status !== 'complete') return;

  if (tab.windowId === lockedWindowId) {
    try {
      await chrome.tabs.setZoom(tabId, LOCKED_ZOOM);
    } catch (e) {
      // Some tabs can't be zoomed
    }
  }
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'toggleLock') {
    (async () => {
      if (isLocked) {
        // Unlock
        isLocked = false;
        lockedWindowId = null;
        await chrome.storage.local.set({ isLocked: false, lockedWindowId: null });
        console.log('[WindowLock] Unlocked');
        sendResponse({ isLocked: false });
      } else {
        // Lock current window
        const currentWindow = await chrome.windows.getCurrent();
        isLocked = true;
        lockedWindowId = currentWindow.id;
        await chrome.storage.local.set({ isLocked: true, lockedWindowId: currentWindow.id });
        await applyLockedSize(currentWindow.id);
        console.log('[WindowLock] Locked window:', lockedWindowId);
        sendResponse({ isLocked: true });
      }
    })();
    return true;
  }

  if (message.action === 'getStatus') {
    sendResponse({ isLocked: isLocked, windowId: lockedWindowId });
    return true;
  }

  if (message.action === 'applyNow') {
    (async () => {
      const currentWindow = await chrome.windows.getCurrent();
      lockedWindowId = currentWindow.id;
      isLocked = true;
      await chrome.storage.local.set({ isLocked: true, lockedWindowId: currentWindow.id });
      await applyLockedSize(currentWindow.id);
      sendResponse({ success: true });
    })();
    return true;
  }
});

// Restore lock state on startup
chrome.runtime.onStartup.addListener(async () => {
  const result = await chrome.storage.local.get(['isLocked', 'lockedWindowId']);
  if (result.isLocked) {
    isLocked = true;
    // Get current window as the locked one
    const currentWindow = await chrome.windows.getCurrent();
    lockedWindowId = currentWindow.id;
    await applyLockedSize(lockedWindowId);
    console.log('[WindowLock] Restored lock on startup');
  }
});

// Auto-lock on install - immediately lock window to 800x600 at 75% zoom
chrome.runtime.onInstalled.addListener(async () => {
  console.log('[WindowLock] Extension installed - auto-locking window');

  // Always auto-lock on install
  isLocked = true;
  const currentWindow = await chrome.windows.getCurrent();
  lockedWindowId = currentWindow.id;
  await chrome.storage.local.set({ isLocked: true, lockedWindowId: currentWindow.id });
  await applyLockedSize(lockedWindowId);

  console.log('[WindowLock] Auto-locked on install to 800x600 at 75% zoom');
});

// Periodic check to maintain lock (backup)
setInterval(async () => {
  if (!isLocked || !lockedWindowId) return;

  try {
    const window = await chrome.windows.get(lockedWindowId);
    if (window.width !== LOCKED_WIDTH || window.height !== LOCKED_HEIGHT) {
      console.log('[WindowLock] Periodic check - fixing size');
      await applyLockedSize(lockedWindowId);
    }
  } catch (e) {
    // Window might be closed
    isLocked = false;
    lockedWindowId = null;
  }
}, 1000);  // Check every second
